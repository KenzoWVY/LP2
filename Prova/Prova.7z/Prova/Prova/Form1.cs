﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Prova
{
    public partial class Form1 : Form
    {
        int[,] listaAlunos = new int[2,5];
        int totalCurso, total;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            total = 0;
            for (int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 5; j++)
                {
                    if(!int.TryParse(Interaction.InputBox("Curso " + (i+1) + ", ano " + (j+1)), out listaAlunos[i, j]))
                    {
                        MessageBox.Show("Número inválido");
                        j--;
                    }
                }
            }
            for(int i = 0; i < 2; i++)
            {
                totalCurso = 0;
                for(int j = 0; j< 5; j++)
                {
                    listBoxResultado.Items.Add("Total do curso " + (i+1) + " do Ano " + (j+1) + ":   " + listaAlunos[i, j].ToString());
                    totalCurso += listaAlunos[i, j];
                }
                listBoxResultado.Items.Add("Total curso " + (i+1) + ":   " + totalCurso);
                listBoxResultado.Items.Add("---------------------------------------------------------");
                total += totalCurso;
            }
            listBoxResultado.Items.Add("Total geral: " + total.ToString());
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxResultado.Items.Clear();
        }
    }
}
