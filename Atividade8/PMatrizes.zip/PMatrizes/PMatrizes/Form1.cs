﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        string auxiliar;

        public Form1()
        {
            InitializeComponent();
        }
        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] reverter = new int[20];
            for (int i = 0; i < reverter.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digitar número " + (i + 1) + ":", "Exercício 1");
                if (!int.TryParse(auxiliar, out reverter[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }
            reverter.Reverse();
            auxiliar = "";
            foreach (int num in reverter)
            {
                auxiliar += num + "\n";
            }
            MessageBox.Show(auxiliar, "Saída");
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");
            auxiliar = "";
            foreach ( string nome in lista )
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar, "Saída");
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            auxiliar = "";
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox("Nota " + (j + 1) + " do aluno " + (i + 1) + ": ");
                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] > 10 || notas[i, j] < 0)
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                }
            }
            auxiliar = "";
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                auxiliar += "Aluno " + (i + 1) + " - Média:" + ((notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3).ToString("#.##") + "\n";
            }
            MessageBox.Show(auxiliar, "Saída");
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmEx4 ex4 = new frmEx4();
            ex4.Show();
            ex4.Text = "Exercício 4";
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmEx5 ex5 = new frmEx5();
            ex5.Show();
            ex5.Text = "Exercício 5";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
