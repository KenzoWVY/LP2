﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmEx4 : Form
    {
        string auxiliar;
        public frmEx4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            auxiliar = "";
            lstbxSaida.Items.Clear();
            string[] listaNomes = new string[10];
            for (int i = 0; i < listaNomes.Length; i++)
            {
                listaNomes[i] = Interaction.InputBox("Digitar nome " + (i + 1));
            }
            foreach (string nome in listaNomes)
            {
                lstbxSaida.Items.Add("O nome " + nome + " tem " + nome.Replace(" ","").Length + " caracteres");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
