﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmEx5 : Form
    {
        public frmEx5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lstbxSaida.Items.Clear();
            char[,] notas = new char[10, 10];
            char[] respostas = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    if (!char.TryParse(Interaction.InputBox("Aluno " + (i + 1) + ", exercício " + (j + 1)).ToUpper(), out notas[i, j]) || !respostas.Contains(notas[i, j]))
                    {
                        MessageBox.Show("Alternativa inválida");
                        j--;
                    }
                }
            }
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    if (notas[i, j] == respostas[j])
                    {
                        lstbxSaida.Items.Add("O aluno " + (i + 1) + " acertou a questão " + (j + 1) + " - Era " + respostas[j] + ", escolheu " + notas[i, j]);
                    }
                    else
                    {
                        lstbxSaida.Items.Add("O aluno " + (i + 1) + " errou a questão " + (j + 1) + " - Era " + respostas[j] + ", escolheu " + notas[i, j]);
                    }
                }
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
