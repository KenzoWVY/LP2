﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }
        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out Peso) || Peso <= 0)
            {
                txtPeso.Text = String.Empty;
                errorPeso.SetError(txtPeso, "Peso inválido");
                txtPeso.Focus();
            }
            else
                errorPeso.Clear();
        }
        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out Altura) || Altura <= 0)
            {
                txtAltura.Text = String.Empty;
                errorAltura.SetError(txtAltura, "Altura inválida");
                txtAltura.Focus();
            }
            else
                errorAltura.Clear();
        }
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / (Math.Pow(Altura, 2));
            IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();
            if (IMC > 40)
                txtTipo.Text = "Obesidade Grave";
            else if (IMC >= 30)
                txtTipo.Text = "Obesidade";
            else if (IMC >= 25)
                txtTipo.Text = "Sobreposto";
            else if (IMC >= 18.5)
                txtTipo.Text = "Normal";
            else
                txtTipo.Text = "Magreza";
                

        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Text = String.Empty;
            txtAltura.Text = String.Empty;
            txtIMC.Text = String.Empty;
            txtTipo.Text = String.Empty;
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
