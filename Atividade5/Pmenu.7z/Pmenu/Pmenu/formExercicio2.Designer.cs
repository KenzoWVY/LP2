﻿namespace Pmenu
{
    partial class formExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvlPalavra1 = new System.Windows.Forms.Label();
            this.lvlPalavra2 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnIguais = new System.Windows.Forms.Button();
            this.btnInserir1 = new System.Windows.Forms.Button();
            this.btnInserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvlPalavra1
            // 
            this.lvlPalavra1.AutoSize = true;
            this.lvlPalavra1.Location = new System.Drawing.Point(263, 135);
            this.lvlPalavra1.Name = "lvlPalavra1";
            this.lvlPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lvlPalavra1.TabIndex = 0;
            this.lvlPalavra1.Text = "Palavra 1";
            // 
            // lvlPalavra2
            // 
            this.lvlPalavra2.AutoSize = true;
            this.lvlPalavra2.Location = new System.Drawing.Point(263, 186);
            this.lvlPalavra2.Name = "lvlPalavra2";
            this.lvlPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lvlPalavra2.TabIndex = 1;
            this.lvlPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(336, 132);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(196, 20);
            this.txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(336, 183);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(196, 20);
            this.txtPalavra2.TabIndex = 3;
            // 
            // btnIguais
            // 
            this.btnIguais.Location = new System.Drawing.Point(262, 234);
            this.btnIguais.Name = "btnIguais";
            this.btnIguais.Size = new System.Drawing.Size(75, 23);
            this.btnIguais.TabIndex = 4;
            this.btnIguais.Text = "Iguais";
            this.btnIguais.UseVisualStyleBackColor = true;
            // 
            // btnInserir1
            // 
            this.btnInserir1.Location = new System.Drawing.Point(361, 234);
            this.btnInserir1.Name = "btnInserir1";
            this.btnInserir1.Size = new System.Drawing.Size(75, 23);
            this.btnInserir1.TabIndex = 5;
            this.btnInserir1.Text = "Inserir 1";
            this.btnInserir1.UseVisualStyleBackColor = true;
            // 
            // btnInserir2
            // 
            this.btnInserir2.Location = new System.Drawing.Point(457, 234);
            this.btnInserir2.Name = "btnInserir2";
            this.btnInserir2.Size = new System.Drawing.Size(75, 23);
            this.btnInserir2.TabIndex = 6;
            this.btnInserir2.Text = "Inserir 2";
            this.btnInserir2.UseVisualStyleBackColor = true;
            // 
            // formExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInserir2);
            this.Controls.Add(this.btnInserir1);
            this.Controls.Add(this.btnIguais);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lvlPalavra2);
            this.Controls.Add(this.lvlPalavra1);
            this.Name = "formExercicio2";
            this.Text = "formExercicio2";
            this.Load += new System.EventHandler(this.formExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lvlPalavra1;
        private System.Windows.Forms.Label lvlPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnIguais;
        private System.Windows.Forms.Button btnInserir1;
        private System.Windows.Forms.Button btnInserir2;
    }
}