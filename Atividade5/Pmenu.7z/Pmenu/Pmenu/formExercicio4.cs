﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class formExercicio4 : Form
    {
        public formExercicio4()
        {
            InitializeComponent();
        }

        private void bntNumeros_Click(object sender, EventArgs e)
        {
            int i = 0;
            int qtdNum = 0;
            while (rchtxtFrase.Text.Length < i)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                {
                    qtdNum++;
                }
            }
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int whiteSpace;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    whiteSpace = i;
                    break;
                }
            }
            MessageBox.Show(String.Concat("Primeiro whitespace: ", whiteSpace));
        }
    }
}
