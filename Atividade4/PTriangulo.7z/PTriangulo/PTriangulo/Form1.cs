﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                errorProvider1.SetError(txtLadoA, "Número inválido");
                txtLadoA.Focus();
            }
            else if (ladoA <= 0)
            {
                errorProvider1.SetError(txtLadoA, "Número deve ser acima de 0");
                txtLadoA.Focus();
            }
            else errorProvider1.Clear();
        }
        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                errorProvider1.SetError(txtLadoB, "Número inválido");
                txtLadoB.Focus();
            }
            else if (ladoB <= 0)
            {
                errorProvider1.SetError(txtLadoB, "Número deve ser acima de 0");
                txtLadoB.Focus();
            }
            else errorProvider1.Clear();
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                errorProvider1.SetError(txtLadoC, "Número inválido");
                txtLadoC.Focus();
            }
            else if (ladoC <= 0)
            {
                errorProvider1.SetError(txtLadoC, "Número deve ser acima de 0");
                txtLadoC.Focus();
            }
            else errorProvider1.Clear();
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if(txtLadoA.Text == String.Empty || txtLadoB.Text == String.Empty || txtLadoC.Text == String.Empty || !(Math.Abs(ladoB - ladoC) < ladoA && ladoA < ladoB + ladoC) || !(Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC) || !(Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB))
            {
                errorProvider2.SetError(txtTipo, "Triângulo inválido");
                txtTipo.Text = string.Empty;
            }
            else
            {
                errorProvider2.Clear();
                if(ladoA == ladoB && ladoB == ladoC)
                {
                    txtTipo.Text = "Equilátero";
                }
                else if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                {
                    txtTipo.Text = "Escaleno";
                }
                else
                {
                    txtTipo.Text = "Isósceles";
                }
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = string.Empty;
            txtLadoB.Text = string.Empty;
            txtLadoC.Text = string.Empty;
            txtTipo.Text = string.Empty;
        }
        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
