﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult fechar = MessageBox.Show("Fechar?", "Fechar", MessageBoxButtons.YesNo);
            if (fechar == DialogResult.Yes)
                Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é possível dividir por zero", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumero2.Clear();
                txtNumero2.Focus();
            }
            else {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }
        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "Número 1 inválido");
                MessageBox.Show("Número Inválido");
                txtNumero1.Focus();
            }
            else
                errorProvider1.SetError(txtNumero1, "");
        }
        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                numero2 = Convert.ToDouble(txtNumero2.Text);
                errorProvider2.SetError(txtNumero2, "");
            }
            catch
            {
                errorProvider2.SetError(txtNumero2, "Número 2 inválido");
                //MessageBox.Show("Número Inválido");
                txtNumero2.Focus();
            }
        }
    }
}
