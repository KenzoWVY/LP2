﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalarioMensal.Text);

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\nMatricula = " + objMensalista.Matricula + "\nTempo Trabalho = " + objMensalista.TempoTrabalho() + "\nSalario Final = " + objMensalista.SalarioBruto());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mensalista obj1 = new Mensalista();

            Mensalista objMensalista = new Mensalista(
            Convert.ToInt32(txtMatricula.Text),
            txtNome.Text,
            Convert.ToDateTime(txtEntrada.Text),
            Convert.ToDouble(txtSalarioMensal.Text));
            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\nMatricula = " + objMensalista.Matricula + "\nTempo Trabalho = " + objMensalista.TempoTrabalho() + "\nSalario Final = " + objMensalista.SalarioBruto());
        }
    }
}
