﻿namespace Ploops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatr = new System.Windows.Forms.TextBox();
            this.txtProd = new System.Windows.Forms.TextBox();
            this.txtSal = new System.Windows.Forms.TextBox();
            this.txtGrat = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMat = new System.Windows.Forms.Label();
            this.lblProd = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblGrat = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.txtSalBruto = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(82, 6);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 0;
            // 
            // txtMatr
            // 
            this.txtMatr.Location = new System.Drawing.Point(82, 32);
            this.txtMatr.Name = "txtMatr";
            this.txtMatr.Size = new System.Drawing.Size(100, 20);
            this.txtMatr.TabIndex = 1;
            // 
            // txtProd
            // 
            this.txtProd.Location = new System.Drawing.Point(82, 58);
            this.txtProd.Name = "txtProd";
            this.txtProd.Size = new System.Drawing.Size(100, 20);
            this.txtProd.TabIndex = 2;
            this.txtProd.Validating += new System.ComponentModel.CancelEventHandler(this.txtProd_Validating);
            // 
            // txtSal
            // 
            this.txtSal.Location = new System.Drawing.Point(82, 84);
            this.txtSal.Name = "txtSal";
            this.txtSal.Size = new System.Drawing.Size(100, 20);
            this.txtSal.TabIndex = 3;
            this.txtSal.Validating += new System.ComponentModel.CancelEventHandler(this.txtSal_Validating);
            // 
            // txtGrat
            // 
            this.txtGrat.Location = new System.Drawing.Point(82, 110);
            this.txtGrat.Name = "txtGrat";
            this.txtGrat.Size = new System.Drawing.Size(100, 20);
            this.txtGrat.TabIndex = 4;
            this.txtGrat.Validating += new System.ComponentModel.CancelEventHandler(this.txtGrat_Validating);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 9);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            // 
            // lblMat
            // 
            this.lblMat.AutoSize = true;
            this.lblMat.Location = new System.Drawing.Point(12, 35);
            this.lblMat.Name = "lblMat";
            this.lblMat.Size = new System.Drawing.Size(52, 13);
            this.lblMat.TabIndex = 6;
            this.lblMat.Text = "Matrícula";
            // 
            // lblProd
            // 
            this.lblProd.AutoSize = true;
            this.lblProd.Location = new System.Drawing.Point(12, 61);
            this.lblProd.Name = "lblProd";
            this.lblProd.Size = new System.Drawing.Size(53, 13);
            this.lblProd.TabIndex = 7;
            this.lblProd.Text = "Produção";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(12, 87);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(39, 13);
            this.lblSal.TabIndex = 8;
            this.lblSal.Text = "Salário";
            // 
            // lblGrat
            // 
            this.lblGrat.AutoSize = true;
            this.lblGrat.Location = new System.Drawing.Point(12, 113);
            this.lblGrat.Name = "lblGrat";
            this.lblGrat.Size = new System.Drawing.Size(64, 13);
            this.lblGrat.TabIndex = 9;
            this.lblGrat.Text = "Gratificação";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(15, 136);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(167, 23);
            this.btnCalcular.TabIndex = 10;
            this.btnCalcular.Text = "Calcular Salário Bruto";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(16, 168);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalBruto.TabIndex = 11;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(82, 165);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.ReadOnly = true;
            this.txtSalBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalBruto.TabIndex = 12;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(197, 194);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblGrat);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.lblProd);
            this.Controls.Add(this.lblMat);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtGrat);
            this.Controls.Add(this.txtSal);
            this.Controls.Add(this.txtProd);
            this.Controls.Add(this.txtMatr);
            this.Controls.Add(this.txtNome);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatr;
        private System.Windows.Forms.TextBox txtProd;
        private System.Windows.Forms.TextBox txtSal;
        private System.Windows.Forms.TextBox txtGrat;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMat;
        private System.Windows.Forms.Label lblProd;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblGrat;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.TextBox txtSalBruto;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}