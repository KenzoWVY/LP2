﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio4 : Form
    {
        int prod;
        double sal, grat;

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double salBruto;
            int B = 0, C = 0, D = 0;
            if (prod >= 100)
                B = 1;
            if (prod >= 120)
                C = 1;
            if (prod >= 150)
                D = 1;
            salBruto = sal + sal * (0.05 * B + 0.1 * C + 0.1 * D) + grat;
            if (salBruto > 7000)
                if (prod < 150 || grat == 0)
                    salBruto = 7000;
            txtSalBruto.Text = salBruto.ToString();
        }
        private void txtProd_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtProd.Text, out prod) || prod < 0)
            {
                errorProvider1.SetError(txtProd, "Produção Inválida");
                txtProd.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void txtSal_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtSal.Text, out sal) || sal < 0)
            {
                errorProvider1.SetError(txtSal, "Salário Inválido");
                txtSal.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void txtGrat_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtGrat.Text, out grat) || grat < 0)
            {
                errorProvider1.SetError(txtGrat, "Gratificação Inválida");
                txtGrat.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }
    }
}
