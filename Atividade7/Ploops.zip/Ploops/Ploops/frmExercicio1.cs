﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int qtdBranco = 0;
            foreach(char c in rchTxtBox.Text)
            {
                if (c == ' ')
                {
                    qtdBranco++;
                }
            }
            txtResultado.Text = qtdBranco.ToString();
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int i = 0, qtdR = 0;
            while(i < rchTxtBox.Text.Length)
            {
                if (rchTxtBox.Text[i] == 'r' || rchTxtBox.Text[i] == 'R')
                {
                    qtdR++;
                }
                i++;
            }
            txtResultado.Text = qtdR.ToString();
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int qtdPares = 0;
            String texto = rchTxtBox.Text + ' ';
            for(int i = 0; i < rchTxtBox.Text.Length; i++)
            {
                if (texto[i] == texto[i+1])
                {
                    qtdPares++;
                }
            }
            txtResultado.Text = qtdPares.ToString();
        }
    }
}
