﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindrome_Click(object sender, EventArgs e)
        {
            String entrada = "", saida = "";
            int i = 0;
            while (i < txtEntrada.Text.Length)
            {
                if (txtEntrada.Text[i] != ' ')
                {
                    entrada += Char.ToLower(txtEntrada.Text[i]);
                }
                i++;
            }
            i = entrada.Length - 1;
            while (i >= 0)
            {
                saida += entrada[i];
                i--;
            }
            if (entrada == saida)
            {
                txtResultado.Text = "Sim";
            }
            else
            {
                txtResultado.Text = "Não";
            }
        }
    }
}
