﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio2 : Form
    {
        int entrada;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtEntrada_Validating(object sender, CancelEventArgs e)
        {
            if (int.TryParse(txtEntrada.Text, out entrada) == false)
            {
                errorProvider1.SetError(txtEntrada, "Número inválido");
                txtEntrada.Focus();
            }
            else if (entrada < 0)
            {
                errorProvider1.SetError(txtEntrada, "Número deve ser maior que 0");
                txtEntrada.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double resultado = 0;
            for(int i = 0; i < entrada; i++)
            {
                resultado += (double)1 / (i + 1);
            }
            txtSaida.Text = resultado.ToString();
        }
    }
}
