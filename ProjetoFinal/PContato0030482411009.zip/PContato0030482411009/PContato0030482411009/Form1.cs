﻿using System.Windows.Forms;
using System.Data.SqlClient;
using System;

namespace PContato0030482411009
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
        
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmContato"];

            if (fc != null)
                fc.Close();

            frmContato FRMC = new frmContato();
            FRMC.MdiParent = this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();

        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form sobre = Application.OpenForms["frmSobre"];

            if (sobre != null)
                sobre.Close();

            frmSobre formSobre = new frmSobre();
            formSobre.MdiParent = this;
            formSobre.WindowState = FormWindowState.Maximized;
            formSobre.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmPrincipal_Load_1(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source = localhost; Initial Catalog = BD; Integrated Security = True; Encrypt = False");

                //  conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=BD;User ID=BD2411009;PASSWORD:BDk7654321k");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir banco de dados: " + ex.Message);
            }

        }
    }
}
